# **App Name**: WeMeet

## Core Features:

- User Authentication: Secure signup/login using username and password; password reset via recovery number.
- Communities Feed: Display posts (text, images, videos) from users in a reverse chronological order.
- Post Interaction: Like and comment on posts.
- Real-time Chat Rooms: Three public rooms (Talent, General, Community) with real-time audio (Talent) and text chat.
- Private Messaging: One-to-one messaging with text, images, and videos.
- Friend Management: Add, remove, and block friends; user search by name.
- Profile Customization: Update profile picture, display name, and status; manage account settings.
- Admin Panel: Hidden admin panel (accessed via code 1911) to moderate content, manage users, and control chat rooms.

## Style Guidelines:

- Primary color: A vibrant blue (#3498DB), evoking trust and connection.
- Background color: Light gray (#ECF0F1), providing a clean and modern backdrop.
- Accent color: A lively purple (#9B59B6) to highlight interactive elements and create a sense of community.
- Font pairing: 'Poppins' (sans-serif) for headlines and 'PT Sans' (sans-serif) for body text, creating a balance of modern and readable design.
- Use a set of clear, outlined icons for navigation and actions, ensuring usability and a modern aesthetic.
- Maintain a consistent layout with a fixed navigation bar and clear content sections, similar to popular social media apps.
- Incorporate subtle transitions and animations to enhance user experience and provide feedback for actions.
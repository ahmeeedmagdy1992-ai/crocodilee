
"use client";

import { useState, useEffect, useMemo } from 'react';
import { Search, MessageSquarePlus } from "lucide-react";
import { ConversationItem } from "@/components/chat/ConversationItem";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from '@/components/ui/button';
import { useFirebase, useMemoFirebase } from "@/firebase";
import { collection, query, where, doc, getDocs, startAt, endAt, orderBy, addDoc, serverTimestamp, onSnapshot, limit } from "firebase/firestore";
import { useDoc } from "@/firebase/firestore/use-doc";
import { useRouter } from 'next/navigation';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { type User } from '@/lib/data';
import { addDocumentNonBlocking } from '@/firebase/non-blocking-updates';
import { errorEmitter, FirestorePermissionError } from '@/firebase';

function ConversationWrapper({ conversation }: { conversation: any }) {
    const { firestore, user } = useFirebase();
    const otherUserId = conversation.users.find((uid: string) => uid !== user?.uid);

    const userDocRef = useMemoFirebase(() => {
        if (!firestore || !otherUserId) return null;
        return doc(firestore, 'users', otherUserId);
    }, [firestore, otherUserId]);

    const { data: otherUser } = useDoc(userDocRef);

    const lastMessageTimestamp = conversation.lastMessage?.createdAt?.toDate();
    const formattedTimestamp = lastMessageTimestamp ? 
        new Intl.DateTimeFormat('ar', { timeStyle: 'short' }).format(lastMessageTimestamp) : 
        '';

    if (!otherUser) {
        return null;
    }

    return (
        <ConversationItem conversation={{
            id: conversation.id,
            user: {
                id: otherUser.id,
                name: otherUser.displayName || 'مستخدم غير معروف',
                avatar: otherUser.profilePictureUrl || ''
            },
            lastMessage: conversation.lastMessage?.content || '...',
            timestamp: formattedTimestamp,
            unread: 0,
        }} isLast={false} />
    );
}

function SearchResultItem({ user: searchUser, onStartChat }: { user: User, onStartChat: (user: User) => void }) {
    return (
        <div className="flex items-center gap-4 p-2 rounded-lg hover:bg-muted/50">
            <Avatar className="h-10 w-10">
                <AvatarImage src={searchUser.profilePictureUrl} alt={searchUser.displayName} />
                <AvatarFallback>{searchUser.displayName?.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
                <p className="font-semibold">{searchUser.displayName}</p>
                <p className="text-sm text-muted-foreground">@{searchUser.username}</p>
            </div>
            <Button size="sm" onClick={() => onStartChat(searchUser)}>
                <MessageSquarePlus className="mr-2 h-4 w-4" />
                دردشة
            </Button>
        </div>
    );
}

export default function ChatsPage() {
  const { firestore, user } = useFirebase();
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState<User[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [conversations, setConversations] = useState<any[]>([]);
  const [isLoadingConversations, setIsLoadingConversations] = useState(true);

  useEffect(() => {
    if (!firestore || !user?.uid) {
        setIsLoadingConversations(false);
        return;
    }

    setIsLoadingConversations(true);
    const chatsRef = collection(firestore, 'private_chats');
    const q = query(chatsRef, where('users', 'array-contains', user.uid));

    const unsubscribe = onSnapshot(q, (querySnapshot) => {
        const convos: any[] = [];
        querySnapshot.forEach((doc) => {
            convos.push({ id: doc.id, ...doc.data() });
        });
        
        const sortedConvos = [...convos].sort((a, b) => {
            const timeA = a.lastMessage?.createdAt?.toDate() || new Date(0);
            const timeB = b.lastMessage?.createdAt?.toDate() || new Date(0);
            return timeB.getTime() - timeA.getTime();
        });

        setConversations(sortedConvos);
        setIsLoadingConversations(false);
    }, (error) => {
        const contextualError = new FirestorePermissionError({
          path: 'private_chats',
          operation: 'list'
        });
        errorEmitter.emit('permission-error', contextualError);
        setIsLoadingConversations(false);
    });

    return () => unsubscribe();
  }, [firestore, user?.uid]);


  useEffect(() => {
    const performSearch = async () => {
        if (!firestore || !user || searchTerm.trim() === "") {
            setSearchResults([]);
            return;
        }

        setIsSearching(true);
        setSearchResults([]);
        
        const usersRef = collection(firestore, "users");
        const q = query(
            usersRef, 
            orderBy('displayName'),
            startAt(searchTerm),
            endAt(searchTerm + '\uf8ff'),
            limit(10)
        );
        
        getDocs(q).then(querySnapshot => {
            const results: User[] = [];
            querySnapshot.forEach((doc) => {
                if (doc.id !== user.uid) {
                    results.push({ id: doc.id, ...doc.data() } as User);
                }
            });
            setSearchResults(results);
            setIsSearching(false);
        }).catch(error => {
            const contextualError = new FirestorePermissionError({
              operation: 'list',
              path: 'users',
            });
            errorEmitter.emit('permission-error', contextualError);
            setIsSearching(false);
        });
    };

    const debounceTimer = setTimeout(() => {
        performSearch();
    }, 300);

    return () => clearTimeout(debounceTimer);

  }, [searchTerm, firestore, user]);

  const handleStartChat = async (chatUser: User) => {
    if (!firestore || !user) return;
    
    // Check if a chat already exists
    const chatsRef = collection(firestore, 'private_chats');
    const q = query(chatsRef, where('users', 'array-contains', user.uid));
    
    getDocs(q).then(querySnapshot => {
        let existingChat = null;
        querySnapshot.forEach(doc => {
            const data = doc.data();
            if (data.users.includes(chatUser.id)) {
                existingChat = { id: doc.id, ...data };
            }
        });
        
        if (existingChat) {
            setSearchTerm("");
            setSearchResults([]);
        } else {
            const newChat = {
                users: [user.uid, chatUser.id],
                createdAt: serverTimestamp(),
                lastMessage: null,
            };
            addDocumentNonBlocking(collection(firestore, 'private_chats'), newChat);
            setSearchTerm("");
            setSearchResults([]);
        }
    }).catch(error => {
       const contextualError = new FirestorePermissionError({
          operation: 'create',
          path: 'private_chats',
        });
        errorEmitter.emit('permission-error', contextualError);
    });
  };


  return (
    <div className="pb-16 sm:pb-0" dir="rtl">
        <Card className="bg-card/80 backdrop-blur-sm">
            <CardHeader className="border-b">
                <div className="relative">
                  <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input 
                    placeholder="ابحث عن مستخدمين لبدء دردشة..." 
                    className="pr-8" 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
            </CardHeader>
            <CardContent className="p-0">
                <div className="flex flex-col">
                    {searchTerm ? (
                        <div className="p-4 space-y-2">
                             {isSearching && <p className="text-center text-muted-foreground">جاري البحث...</p>}
                             {!isSearching && searchResults.length === 0 && <p className="text-center text-muted-foreground">لم يتم العثور على مستخدمين.</p>}
                             {searchResults.map(user => (
                                <SearchResultItem key={user.id} user={user} onStartChat={handleStartChat} />
                             ))}
                        </div>
                    ) : (
                        <>
                            {isLoadingConversations && <p className="text-center p-8 text-muted-foreground">جار تحميل المحادثات...</p>}
                            {conversations?.map((convo) => (
                              <ConversationWrapper key={convo.id} conversation={convo} />
                            ))}
                            {!isLoadingConversations && conversations?.length === 0 && (
                              <p className="text-muted-foreground text-center p-8">لا توجد دردشات بعد. ابحث عن مستخدم لبدء محادثة.</p>
                            )}
                        </>
                    )}
                </div>
            </CardContent>
        </Card>
    </div>
  );
}

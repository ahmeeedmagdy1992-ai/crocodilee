
"use client";

import { PlusCircle, Image as ImageIcon, Video, X, UploadCloud } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PostCard } from "@/components/feed/PostCard";
import { RoomsSheet } from "@/components/feed/RoomsSheet";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useCollection, useFirebase, useMemoFirebase } from "@/firebase";
import { addDocumentNonBlocking } from "@/firebase/non-blocking-updates";
import { collection, serverTimestamp, query, orderBy, doc } from "firebase/firestore";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { useDoc } from "@/firebase/firestore/use-doc";
import { type Post as PostType } from "@/lib/data";
import { useState, useCallback, useEffect } from "react";
import Image from "next/image";
import { useDropzone } from "react-dropzone";
import { cn } from "@/lib/utils";

const postSchema = z.object({
  content: z.string().max(280, "Post cannot exceed 280 characters.").optional(),
  imageUrl: z.string().optional().or(z.literal('')),
  videoUrl: z.string().optional().or(z.literal('')),
}).refine(data => data.content || data.imageUrl || data.videoUrl, {
    message: "يجب أن يحتوي المنشور على نص أو صورة أو فيديو على الأقل.",
    path: ["content"],
});


function PostWrapper({ post }: { post: PostType & { authorId: string, createdAt: any, likes: string[], commentCount: number } }) {
    const { firestore } = useFirebase();

    const authorRef = useMemoFirebase(() => {
        if (!firestore) return null;
        return doc(firestore, 'users', post.authorId);
    }, [firestore, post.authorId]);

    const { data: author } = useDoc(authorRef);

    if (!author) {
        return (
            <Card>
                <CardContent>
                    <p>Loading post...</p>
                </CardContent>
            </Card>
        );
    }
    
    return (
        <PostCard post={{
          id: post.id,
          author: {
            id: author.id,
            name: author.displayName || 'Unknown User',
            avatar: author.profilePictureUrl || ''
          },
          content: post.content,
          likes: post.likes || [],
          commentCount: post.commentCount || 0,
          comments: 0, // This is now handled by commentCount
          timestamp: post.createdAt?.toDate().toLocaleDateString('ar') || 'الآن',
          ...(post.imageUrl && {image: {url: post.imageUrl, hint: ''}}),
          ...(post.videoUrl && {video: {url: post.videoUrl, hint: ''}})
        }} />
    );
}

export default function CommunitiesPage() {
  const { firestore, user } = useFirebase();
  const [mediaType, setMediaType] = useState<'image' | 'video' | null>(null);
  const [mediaPreview, setMediaPreview] = useState<string | null>(null);

  const postsCollectionRef = useMemoFirebase(() => {
    if (!firestore) return null;
    return collection(firestore, "posts");
  }, [firestore]);

  const postsQuery = useMemoFirebase(() => {
    if (!postsCollectionRef) return null;
    return query(postsCollectionRef, orderBy("createdAt", "desc"));
  },[postsCollectionRef]);

  const { data: posts, isLoading } = useCollection(postsQuery);
  
  const form = useForm<z.infer<typeof postSchema>>({
    resolver: zodResolver(postSchema),
    defaultValues: { 
      content: "",
      imageUrl: "",
      videoUrl: ""
    },
  });
  
  useEffect(() => {
    // Cleanup the object URL to avoid memory leaks
    return () => {
      if (mediaPreview && mediaPreview.startsWith('blob:')) {
        URL.revokeObjectURL(mediaPreview);
      }
    };
  }, [mediaPreview]);


  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      if (mediaPreview && mediaPreview.startsWith('blob:')) {
        URL.revokeObjectURL(mediaPreview);
      }

      const reader = new FileReader();
      reader.onload = (e: ProgressEvent<FileReader>) => {
        if (typeof e.target?.result === 'string') {
          setMediaPreview(e.target.result);
          if (mediaType === 'image') {
            form.setValue('imageUrl', e.target.result, { shouldValidate: true });
          } else if (mediaType === 'video') {
            form.setValue('videoUrl', e.target.result, { shouldValidate: true });
          }
          form.clearErrors('content');
        }
      };
      reader.readAsDataURL(file);
    }
  }, [form, mediaType, mediaPreview]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: mediaType === 'image' ? { 'image/*': [] } : { 'video/*': ['.mp4', '.webm', '.mov'] },
    multiple: false,
  });

  const onSubmit = (values: z.infer<typeof postSchema>) => {
    if (!postsCollectionRef || !user) return;
    
    // Use mediaPreview for the imageUrl/videoUrl if it exists (it will be a data URL)
    const finalImageUrl = mediaType === 'image' && mediaPreview ? mediaPreview : "";
    const finalVideoUrl = mediaType === 'video' && mediaPreview ? mediaPreview : "";

    if (!values.content && !finalImageUrl && !finalVideoUrl) {
        form.setError("content", { message: "يجب أن يحتوي المنشور على نص أو صورة أو فيديو على الأقل." });
        return;
    }

    const newPost = {
      authorId: user.uid,
      content: values.content,
      likes: [],
      commentCount: 0,
      createdAt: serverTimestamp(),
      ...(finalImageUrl ? { imageUrl: finalImageUrl } : {}),
      ...(finalVideoUrl ? { videoUrl: finalVideoUrl } : {}),
    };

    addDocumentNonBlocking(postsCollectionRef, newPost);
    form.reset();
    setMediaType(null);
    setMediaPreview(null);
  };

  const handleMediaToggle = (type: 'image' | 'video') => {
    if (mediaType === type) {
        setMediaType(null);
        removeMedia();
    } else {
        removeMedia();
        setMediaType(type);
    }
  }
  
  const removeMedia = () => {
    if (mediaPreview && mediaPreview.startsWith('blob:')) {
      URL.revokeObjectURL(mediaPreview);
    }
    form.setValue('imageUrl', '');
    form.setValue('videoUrl', '');
    setMediaPreview(null);
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pb-16 sm:pb-0" dir="rtl">
      <div className="lg:col-span-2 flex flex-col gap-8">
        <Card className="bg-card/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="font-headline">إنشاء منشور</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="flex flex-col gap-4">
                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Textarea placeholder="بماذا تفكر؟" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {mediaType && (
                    <div>
                      {!mediaPreview ? (
                        <div {...getRootProps()} className={cn("flex flex-col items-center justify-center w-full py-10 border-2 border-dashed rounded-lg cursor-pointer bg-muted hover:bg-muted/80 transition-colors", isDragActive && "border-primary")}>
                          <input {...getInputProps()} />
                          <UploadCloud className="w-10 h-10 mb-4 text-muted-foreground" />
                          <p className="mb-2 text-sm text-muted-foreground"><span className="font-semibold">انقر للرفع</span> أو اسحب وأفلت</p>
                          <p className="text-xs text-muted-foreground">{mediaType === 'image' ? 'صورة' : 'فيديو'}</p>
                        </div>
                      ) : (
                         <div className="relative aspect-video w-full overflow-hidden rounded-lg border">
                            {mediaType === 'image' && mediaPreview && (
                                <Image src={mediaPreview} alt="معاينة الصورة" fill className="object-contain"/>
                            )}
                            {mediaType === 'video' && mediaPreview && (
                                <video src={mediaPreview} controls className="w-full h-full object-contain bg-black" />
                            )}
                            <Button variant="destructive" size="icon" className="absolute top-2 right-2 h-6 w-6 z-10" onClick={removeMedia}>
                                <X className="h-4 w-4"/>
                            </Button>
                        </div>
                      )}
                    </div>
                )}

                <div className="flex justify-between items-center">
                    <div className="flex gap-2">
                        <Button variant="ghost" size="icon" type="button" onClick={() => handleMediaToggle("image")}>
                            <ImageIcon className={mediaType === 'image' ? "text-primary" : "text-muted-foreground"} />
                        </Button>
                         <Button variant="ghost" size="icon" type="button" onClick={() => handleMediaToggle("video")}>
                            <Video className={mediaType === 'video' ? "text-primary" : "text-muted-foreground"} />
                        </Button>
                    </div>
                  <Button type="submit">نشر</Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>

        <div className="flex flex-col gap-8">
          {isLoading && <p>جار تحميل المنشورات...</p>}
          {posts?.map((post) => (
             <PostWrapper key={post.id} post={post as any} />
          ))}
        </div>
      </div>

      <aside className="hidden lg:flex flex-col gap-8">
        <Card className="bg-card/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="font-headline">الغرف</CardTitle>
          </CardHeader>
          <CardContent>
            <RoomsSheet trigger={
                <Button variant="outline" className="w-full">
                    استكشاف الغرف
                </Button>
            } />
          </CardContent>
        </Card>
      </aside>

      <div className="lg:hidden fixed bottom-20 right-4">
        <RoomsSheet trigger={
            <Button size="icon" className="rounded-full w-14 h-14 shadow-lg">
                <PlusCircle className="w-6 h-6"/>
            </Button>
        } />
      </div>
    </div>
  );
}

    
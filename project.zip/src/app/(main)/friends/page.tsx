
"use client";
import { Search } from "lucide-react";
import { UserCard } from "@/components/friends/UserCard";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useCollection, useFirebase, useMemoFirebase, FirestorePermissionError, errorEmitter } from "@/firebase";
import { collection, query, where, documentId, getDocs, startAt, endAt, orderBy, or } from "firebase/firestore";
import { useState, useEffect, useMemo } from "react";
import { type User as UserType, type FriendRequest } from "@/lib/data";
import { FriendRequestCard } from "@/components/friends/FriendRequestCard";

function FriendUserCard({ userId }: { userId: string }) {
    const { firestore, user } = useFirebase();
    const userRef = useMemoFirebase(() => {
        if (!firestore) return null;
        return query(collection(firestore, "users"), where(documentId(), "==", userId));
    }, [firestore, userId]);
    
    const { data: userArr } = useCollection<UserType>(userRef);

    if (!userArr || userArr.length === 0) {
        return null;
    }
    const friendUser = userArr[0];

    return (
         <UserCard key={friendUser.id} user={{
            id: friendUser.id,
            name: friendUser.displayName || '',
            avatar: friendUser.profilePictureUrl || '',
            status: friendUser.status
        }} friendshipStatus="friend" />
    )
}


export default function FriendsPage() {
  const { firestore, user } = useFirebase();
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState<UserType[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // --- Friends ---
  const friendsCollectionRef = useMemoFirebase(() => {
    if (!firestore || !user) return null;
    return collection(firestore, "users", user.uid, "friends");
  }, [firestore, user]);
  const { data: friendDocs } = useCollection(friendsCollectionRef);
  const friendIds = useMemo(() => friendDocs?.map(f => f.id) || [], [friendDocs]);
  
  // --- Friend Requests (Incoming) ---
  const incomingRequestsRef = useMemoFirebase(() => {
    if(!firestore || !user) return null;
    return query(collection(firestore, 'friend_requests'), where('receiverId', '==', user.uid), where('status', '==', 'pending'));
  }, [firestore, user]);
  const { data: incomingRequests } = useCollection<FriendRequest>(incomingRequestsRef);

  // --- Friend Requests (Sent) ---
  const sentRequestsRef = useMemoFirebase(() => {
    if(!firestore || !user) return null;
    return query(collection(firestore, 'friend_requests'), where('senderId', '==', user.uid), where('status', '==', 'pending'));
  }, [firestore, user]);
  const { data: sentRequests } = useCollection<FriendRequest>(sentRequestsRef);
  const sentRequestReceiverIds = useMemo(() => sentRequests?.map(r => r.receiverId) || [], [sentRequests]);


  useEffect(() => {
    const performSearch = async () => {
        if (!firestore || !user || searchTerm.trim() === "") {
            setSearchResults([]);
            return;
        }

        setIsSearching(true);
        const usersRef = collection(firestore, "users");
        const q = query(
            usersRef,
            orderBy('displayName'),
            startAt(searchTerm),
            endAt(searchTerm + '\uf8ff')
        );

        getDocs(q).then(querySnapshot => {
            const results: UserType[] = [];
            querySnapshot.forEach((doc) => {
                if (doc.id !== user.uid) {
                    results.push({ id: doc.id, ...doc.data() } as UserType);
                }
            });
            setSearchResults(results);
        }).catch(error => {
            const contextualError = new FirestorePermissionError({
                operation: 'list',
                path: 'users'
            });
            errorEmitter.emit('permission-error', contextualError);
        }).finally(() => {
            setIsSearching(false);
        });
    };

    const debounceTimer = setTimeout(() => {
        performSearch();
    }, 300);

    return () => clearTimeout(debounceTimer);

  }, [searchTerm, firestore, user]);

  const getFriendshipStatus = (targetUserId: string) => {
    if(friendIds.includes(targetUserId)) return 'friend';
    if(sentRequestReceiverIds.includes(targetUserId)) return 'pending_sent';
    return 'not_friend';
  }

  return (
    <div className="pb-16 sm:pb-0" dir="rtl">
    <Tabs defaultValue="friends">
      <TabsList className="grid w-full grid-cols-3 bg-card/80 backdrop-blur-sm">
        <TabsTrigger value="friends">أصدقائي</TabsTrigger>
        <TabsTrigger value="requests">الطلبات <span className="mr-2 bg-primary text-primary-foreground text-xs w-5 h-5 rounded-full flex items-center justify-center">{incomingRequests?.length || 0}</span></TabsTrigger>
        <TabsTrigger value="search">بحث</TabsTrigger>
      </TabsList>
      <TabsContent value="friends">
        <Card className="bg-card/80 backdrop-blur-sm">
            <CardHeader>
                <CardTitle className="font-headline">أصدقائي ({friendIds.length})</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-2 xl:grid-cols-3 gap-4">
                {friendIds.map(friendId => (
                    <FriendUserCard key={friendId} userId={friendId} />
                ))}
                 {friendIds.length === 0 && (
                    <p className="text-muted-foreground text-center py-8 col-span-full">لم تقم بإضافة أي أصدقاء بعد.</p>
                )}
            </CardContent>
        </Card>
      </TabsContent>
       <TabsContent value="requests">
        <Card className="bg-card/80 backdrop-blur-sm">
            <CardHeader>
                <CardTitle className="font-headline">طلبات الصداقة</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-2 xl:grid-cols-3 gap-4">
                {incomingRequests?.map(request => (
                    <FriendRequestCard key={request.id} request={request} />
                ))}
                 {!incomingRequests || incomingRequests.length === 0 && (
                    <p className="text-muted-foreground text-center py-8 col-span-full">لا توجد طلبات صداقة جديدة.</p>
                )}
            </CardContent>
        </Card>
      </TabsContent>
      <TabsContent value="search">
        <Card className="bg-card/80 backdrop-blur-sm">
          <CardHeader>
             <div className="relative">
              <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="ابحث عن مستخدمين..." 
                className="pr-8" 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </CardHeader>
          <CardContent className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-2 xl:grid-cols-3 gap-4">
             {isSearching ? (
                <p className="text-muted-foreground text-center py-8 col-span-full">جار البحث...</p>
             ): searchTerm ? (
                searchResults.length > 0 ? (
                  searchResults.map(searchUser => (
                     <UserCard key={searchUser.id} user={{
                       id: searchUser.id,
                       name: searchUser.displayName || '',
                       avatar: searchUser.profilePictureUrl || '',
                       status: searchUser.status
                     }} friendshipStatus={getFriendshipStatus(searchUser.id)} />
                  ))
                ) : (
                  <p className="text-muted-foreground text-center py-8 col-span-full">لم يتم العثور على مستخدمين.</p>
                )
             ) : (
                <p className="text-muted-foreground text-center py-8 col-span-full">ابحث عن مستخدمين لإضافتهم كأصدقاء.</p>
             )}
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
    </div>
  );
}

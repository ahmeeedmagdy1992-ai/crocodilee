import { AppShell } from "@/components/layout/AppShell";
import Image from "next/image";

export default function MainLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="relative min-h-screen w-full">
       <Image
        src="https://images.unsplash.com/photo-1551434678-e076c223a692?q=80&w=2070&auto=format&fit=crop"
        alt="App Background"
        fill
        className="object-cover -z-20"
      />
      <div className="absolute inset-0 bg-blue-100/30 dark:bg-blue-900/50 -z-10" />
      <AppShell>{children}</AppShell>
    </div>
  );
}

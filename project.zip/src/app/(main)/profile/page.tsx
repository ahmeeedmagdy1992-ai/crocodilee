
"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useFirebase, useMemoFirebase } from "@/firebase";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useDoc } from "@/firebase/firestore/use-doc";
import { doc, collection, query, where, orderBy } from "firebase/firestore";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { updateDocumentNonBlocking } from "@/firebase/non-blocking-updates";
import { useToast } from "@/hooks/use-toast";
import { useEffect, useState, useMemo } from "react";
import { AvatarSelectionDialog } from "@/components/profile/AvatarSelectionDialog";
import { Edit } from "lucide-react";
import { useCollection } from "@/firebase/firestore/use-collection";
import { type Post as PostType } from "@/lib/data";
import { PostCard } from "@/components/feed/PostCard";

const profileSchema = z.object({
  status: z.string().optional(),
});


function PostWrapper({ post }: { post: PostType & { authorId: string, createdAt: any, likes: string[], commentCount: number } }) {
    const { firestore } = useFirebase();

    const authorRef = useMemoFirebase(() => {
        if (!firestore) return null;
        return doc(firestore, 'users', post.authorId);
    }, [firestore, post.authorId]);

    const { data: author } = useDoc(authorRef);

    if (!author) {
        return (
            <Card>
                <CardContent>
                    <p>Loading post...</p>
                </CardContent>
            </Card>
        );
    }
    
    return (
        <PostCard post={{
          id: post.id,
          author: {
            id: author.id,
            name: author.displayName || 'Unknown User',
            avatar: author.profilePictureUrl || ''
          },
          content: post.content,
          likes: post.likes || [],
          commentCount: post.commentCount || 0,
          comments: 0, // This is now handled by commentCount
          timestamp: post.createdAt?.toDate().toLocaleDateString('ar') || 'الآن',
          ...(post.imageUrl && {image: {url: post.imageUrl, hint: ''}}),
          ...(post.videoUrl && {video: {url: post.videoUrl, hint: ''}})
        }} />
    );
}

export default function ProfilePage() {
  const { user, firestore } = useFirebase();
  const { toast } = useToast();
  const [isAvatarDialogOpen, setIsAvatarDialogOpen] = useState(false);

  const userRef = useMemoFirebase(() => {
    if (!user || !firestore) return null;
    return doc(firestore, "users", user.uid);
  }, [firestore, user]);

  const { data: userProfile, isLoading: isProfileLoading } = useDoc(userRef);

  const postsCollectionRef = useMemoFirebase(() => {
    if (!firestore) return null;
    return collection(firestore, "posts");
  }, [firestore]);

  const allPostsQuery = useMemoFirebase(() => {
    if (!postsCollectionRef) return null;
    return query(postsCollectionRef, orderBy("createdAt", "desc"));
  }, [postsCollectionRef]);

  const { data: allPosts, isLoading: arePostsLoading } = useCollection(allPostsQuery);

  const userPosts = useMemo(() => {
    if (!user || !allPosts) return [];
    return allPosts.filter(post => post.authorId === user.uid);
  }, [allPosts, user]);


  const form = useForm<z.infer<typeof profileSchema>>({
    resolver: zodResolver(profileSchema),
    values: {
        status: userProfile?.status || "",
    }
  });
  
  useEffect(() => {
    if (userProfile) {
      form.reset({
        status: userProfile.status || "",
      });
    }
  }, [userProfile, form]);


  if (isProfileLoading) {
    return <div>Loading profile...</div>;
  }

  if (!userProfile) {
    return <div>Loading your profile...</div>;
  }
  
  const handleProfileUpdate = (values: z.infer<typeof profileSchema>) => {
    if (!userRef) return;
    updateDocumentNonBlocking(userRef, values);
    toast({ title: "Profile Updated", description: "Your changes have been saved." });
  }
  
  const handleAvatarSelect = (imageUrl: string) => {
    if (!userRef) return;
     updateDocumentNonBlocking(userRef, { profilePictureUrl: imageUrl });
        toast({
            title: "تم تحديث الصورة",
            description: "تم تغيير صورة ملفك الشخصي بنجاح.",
        });
    setIsAvatarDialogOpen(false);
  }


  return (
    <>
    <div className="grid gap-8 pb-16 sm:pb-0" dir="rtl">
      <Card className="bg-card/80 backdrop-blur-sm">
        <CardContent className="p-6 flex flex-col sm:flex-row items-center gap-6">
            <div className="relative group">
                <Avatar className="h-24 w-24">
                    <AvatarImage src={userProfile.profilePictureUrl} />
                    <AvatarFallback>{userProfile.displayName?.charAt(0)}</AvatarFallback>
                </Avatar>
                <Button 
                  size="icon" 
                  className="absolute inset-0 m-auto h-12 w-12 rounded-full bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity" 
                  onClick={() => setIsAvatarDialogOpen(true)}
                >
                    <Edit className="h-6 w-6"/>
                </Button>
            </div>
            <div className="text-center sm:text-left">
                <h2 className="text-2xl font-bold font-headline">{userProfile.displayName}</h2>
                <p className="text-muted-foreground">{userProfile.status}</p>
            </div>
        </CardContent>
      </Card>
      
      <Card className="bg-card/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="font-headline">تعديل الملف الشخصي</CardTitle>
          <CardDescription>
            قم بإجراء تغييرات على ملفك الشخصي العام.
          </CardDescription>
        </CardHeader>
        <CardContent>
            <Form {...form}>
                <form onSubmit={form.handleSubmit(handleProfileUpdate)} className="space-y-4">
                     <FormField
                        control={form.control}
                        name="status"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>الحالة</FormLabel>
                                <FormControl>
                                    <Textarea {...field} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <Button type="submit">حفظ التغييرات</Button>
                </form>
            </Form>
        </CardContent>
      </Card>

      <div>
        <h2 className="text-2xl font-bold font-headline mb-4 text-white">منشوراتي</h2>
        <div className="flex flex-col gap-8">
            {arePostsLoading && <p className="text-white">جار تحميل المنشورات...</p>}
            {userPosts.map((post) => (
                <PostWrapper key={post.id} post={post as any} />
            ))}
            {!arePostsLoading && userPosts.length === 0 && (
                <p className="text-muted-foreground text-center py-8">لم تقم بنشر أي شيء بعد.</p>
            )}
        </div>
      </div>

    </div>
     <AvatarSelectionDialog 
        open={isAvatarDialogOpen}
        onOpenChange={setIsAvatarDialogOpen}
        onSelect={handleAvatarSelect}
      />
    </>
  );
}

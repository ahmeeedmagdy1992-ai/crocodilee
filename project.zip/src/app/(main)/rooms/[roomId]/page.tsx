
'use client';

import { useEffect, useRef, useState } from 'react';
import { notFound } from 'next/navigation';
import { useFirebase, useMemoFirebase } from '@/firebase';
import {
  collection,
  doc,
  query,
  orderBy,
  serverTimestamp,
} from 'firebase/firestore';
import { useCollection } from '@/firebase/firestore/use-collection';
import { useDoc } from '@/firebase/firestore/use-doc';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Send } from 'lucide-react';
import { addDocumentNonBlocking } from '@/firebase/non-blocking-updates';
import { formatDistanceToNow } from 'date-fns';
import { ar } from 'date-fns/locale';

function Message({ message }: { message: any }) {
  const { firestore } = useFirebase();
  const authorRef = useMemoFirebase(() => {
    if (!firestore) return null;
    return doc(firestore, 'users', message.senderId);
  }, [firestore, message.senderId]);
  const { data: author } = useDoc(authorRef);

  const timeAgo = message.createdAt
    ? formatDistanceToNow(message.createdAt.toDate(), {
        addSuffix: true,
        locale: ar,
      })
    : 'الآن';

  if (!author) {
    return (
      <div className="flex items-start gap-4 p-4">
        <div className="h-10 w-10 rounded-full bg-muted animate-pulse" />
        <div className="grid gap-1.5 flex-1">
            <div className="flex items-center gap-2">
                <div className="h-4 w-20 bg-muted animate-pulse rounded" />
                <div className="h-3 w-12 bg-muted animate-pulse rounded" />
            </div>
            <div className="h-4 w-40 bg-muted animate-pulse rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-start gap-4 p-4">
      <Avatar>
        <AvatarImage src={author.profilePictureUrl} />
        <AvatarFallback>{author.displayName?.charAt(0)}</AvatarFallback>
      </Avatar>
      <div className="grid gap-1.5">
        <div className="flex items-center gap-2">
          <p className="font-semibold">{author.displayName}</p>
          <p className="text-xs text-muted-foreground">{timeAgo}</p>
        </div>
        <div>{message.content}</div>
      </div>
    </div>
  );
}


export default function RoomPage({ params }: { params: { roomId: string } }) {
  const { roomId } = params;
  const { firestore, user } = useFirebase();
  const [message, setMessage] = useState('');
  const viewportRef = useRef<HTMLDivElement>(null);

  const roomRef = useMemoFirebase(() => {
    if (!firestore || !roomId) return null;
    return doc(firestore, 'chat_rooms', roomId);
  }, [firestore, roomId]);

  const { data: room, isLoading: isRoomLoading } = useDoc(roomRef);

  const messagesRef = useMemoFirebase(() => {
    if (!roomRef) return null;
    return collection(roomRef, 'messages');
  }, [roomRef]);

  const messagesQuery = useMemoFirebase(() => {
    if (!messagesRef) return null;
    return query(messagesRef, orderBy('createdAt', 'asc'));
  }, [messagesRef]);

  const { data: messages } = useCollection(messagesQuery);

  useEffect(() => {
    if (viewportRef.current) {
        setTimeout(() => {
             if(viewportRef.current) {
                viewportRef.current.scrollTop = viewportRef.current.scrollHeight;
             }
        }, 100);
    }
  }, [messages]);

  if (isRoomLoading) {
    return <div className="flex items-center justify-center h-full">جار تحميل الغرفة...</div>;
  }

  if (!room) {
    notFound();
    return null;
  }

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messagesRef || !user || message.trim() === '') return;
    const newMessage = {
      senderId: user.uid,
      content: message,
      createdAt: serverTimestamp(),
    };
    addDocumentNonBlocking(messagesRef, newMessage);
    setMessage('');
  };

  return (
    <div className="h-[calc(100vh-8rem)] sm:h-full flex flex-col" dir="rtl">
        <Card className="flex-1 flex flex-col bg-card/80 backdrop-blur-sm overflow-hidden">
            <CardHeader className="border-b flex-shrink-0">
                <CardTitle className="font-headline">{room.name}</CardTitle>
            </CardHeader>
            <CardContent className="flex-1 p-0 overflow-y-auto" ref={viewportRef}>
                 <div className="p-4 space-y-4">
                    {messages?.map(msg => (
                        <Message key={msg.id} message={msg} />
                    ))}
                </div>
            </CardContent>
            <CardFooter className="border-t p-4 flex-shrink-0 bg-background/95">
                <form onSubmit={handleSendMessage} className="flex w-full items-center gap-2">
                <Input
                    placeholder="اكتب رسالتك..."
                    value={message}
                    onChange={e => setMessage(e.target.value)}
                />
                <Button type="submit" size="icon" disabled={!message.trim()}>
                    <Send className="h-4 w-4" />
                </Button>
                </form>
            </CardFooter>
        </Card>
    </div>
  );
}


"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useFirebase, useMemoFirebase } from "@/firebase";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { AdminPanel } from "@/components/admin/AdminPanel";
import { useDoc } from "@/firebase/firestore/use-doc";
import { doc } from "firebase/firestore";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { updateDocumentNonBlocking } from "@/firebase/non-blocking-updates";
import { useToast } from "@/hooks/use-toast";
import { useEffect, useState } from "react";
import { signOut } from "firebase/auth";
import { useRouter } from "next/navigation";
import { useTheme } from "next-themes";
import { Moon, Sun, Edit } from "lucide-react";
import { cn } from "@/lib/utils";
import { AvatarSelectionDialog } from "@/components/profile/AvatarSelectionDialog";
import { ChangeEmailDialog } from "@/components/settings/ChangeEmailDialog";

const profileSchema = z.object({
  status: z.string().optional(),
});

export default function SettingsPage() {
  const { user, firestore, auth } = useFirebase();
  const { toast } = useToast();
  const router = useRouter();
  const { theme, setTheme } = useTheme();
  const [isAvatarDialogOpen, setIsAvatarDialogOpen] = useState(false);
  const [isEmailDialogOpen, setIsEmailDialogOpen] = useState(false);

  const userRef = useMemoFirebase(() => {
    if (!user || !firestore) return null;
    return doc(firestore, "users", user.uid);
  }, [firestore, user]);

  const { data: userProfile, isLoading } = useDoc(userRef);

  const form = useForm<z.infer<typeof profileSchema>>({
    resolver: zodResolver(profileSchema),
    values: {
        status: userProfile?.status || "",
    }
  });
  
  useEffect(() => {
    if (userProfile) {
      form.reset({
        status: userProfile.status || "",
      });
    }
  }, [userProfile, form]);

  const handleLogout = async () => {
    if (!auth) return;
    await signOut(auth);
    router.push("/login");
  };

  const handleFeatureNotAvailable = (featureName: string) => {
    toast({
      title: "الميزة قيد التطوير",
      description: `ميزة ${featureName} ستكون متاحة قريبًا.`,
    });
  };

 const handleAvatarSelect = (imageUrl: string) => {
    if (!userRef) return;
    updateDocumentNonBlocking(userRef, { profilePictureUrl: imageUrl });
    toast({
        title: "تم تحديث الصورة",
        description: "تم تغيير صورة ملفك الشخصي بنجاح.",
    });
    setIsAvatarDialogOpen(false);
  };

  if (isLoading) {
    return <div>جار تحميل الملف الشخصي...</div>;
  }

  if (!userProfile) {
    return <div>جار تحميل ملفك الشخصي...</div>;
  }
  
  const handleProfileUpdate = (values: z.infer<typeof profileSchema>) => {
    if (!userRef) return;
    updateDocumentNonBlocking(userRef, values);
    toast({ title: "تم تحديث الملف الشخصي", description: "تم حفظ تغييراتك." });
  }

  return (
    <>
    <div className="grid gap-8 pb-16 sm:pb-0" dir="rtl">
      <Card className="bg-card/80 backdrop-blur-sm">
        <CardHeader>
            <CardTitle className="font-headline">الإعدادات</CardTitle>
            <CardDescription>إدارة حسابك وتفضيلاتك.</CardDescription>
        </CardHeader>
        <CardContent className="p-6 flex flex-col items-center gap-6 text-center">
            <div className="relative group">
                <Avatar className="h-24 w-24">
                    <AvatarImage src={userProfile.profilePictureUrl} />
                    <AvatarFallback>{userProfile.displayName?.charAt(0)}</AvatarFallback>
                </Avatar>
                <Button 
                  size="icon" 
                  className="absolute inset-0 m-auto h-12 w-12 rounded-full bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity" 
                  onClick={() => setIsAvatarDialogOpen(true)}
                >
                    <Edit className="h-6 w-6"/>
                </Button>
            </div>
            <div>
                <h2 className="text-2xl font-bold font-headline">{userProfile.displayName}</h2>
                <p className="text-muted-foreground">{userProfile.status}</p>
            </div>
        </CardContent>
      </Card>

      <Card className="bg-card/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="font-headline">المظهر</CardTitle>
          <CardDescription>اختر كيف تريد أن يظهر التطبيق.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-2">
            <Button
              variant={"outline"}
              className={cn("h-12", theme === "light" && "border-primary ring-2 ring-primary")}
              onClick={() => setTheme("light")}
            >
              <Sun className="mr-2" />
              فاتح
            </Button>
            <Button
              variant={"outline"}
              className={cn("h-12", theme === "dark" && "border-primary ring-2 ring-primary")}
              onClick={() => setTheme("dark")}
            >
              <Moon className="mr-2" />
              داكن
            </Button>
             <Button
              variant={"outline"}
              className={cn("h-12", theme === "system" && "border-primary ring-2 ring-primary")}
              onClick={() => setTheme("system")}
            >
              النظام
            </Button>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-card/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="font-headline">تعديل الملف الشخصي</CardTitle>
        </CardHeader>
        <CardContent>
            <Form {...form}>
                <form onSubmit={form.handleSubmit(handleProfileUpdate)} className="space-y-4">
                     <FormField
                        control={form.control}
                        name="status"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>الحالة</FormLabel>
                                <FormControl>
                                    <Textarea {...field} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <Button type="submit">حفظ التغييرات</Button>
                </form>
            </Form>
        </CardContent>
      </Card>

      <Card className="bg-card/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="font-headline">إعدادات الحساب</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4 rounded-lg border border-border p-4">
             <h3 className="font-semibold">تغيير كلمة المرور</h3>
              <div className="space-y-2">
                <Label htmlFor="current-password">كلمة المرور الحالية</Label>
                <Input id="current-password" type="password" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="new-password">كلمة المرور الجديدة</Label>
                <Input id="new-password" type="password" />
              </div>
              <Button onClick={() => handleFeatureNotAvailable("تغيير كلمة المرور")}>تحديث كلمة المرور</Button>
          </div>
           <div className="space-y-4 rounded-lg border border-border p-4">
             <h3 className="font-semibold">البريد الإلكتروني</h3>
             <p className="text-sm text-muted-foreground">{user?.email || "لم يتم تعيين بريد إلكتروني."}</p>
             <Button variant="outline" onClick={() => setIsEmailDialogOpen(true)}>تغيير البريد الإلكتروني</Button>
          </div>
          <div className="space-y-4 rounded-lg border border-destructive p-4">
             <h3 className="font-semibold text-destructive">منطقة الخطر</h3>
             <div className="flex flex-wrap gap-2">
                <Button variant="destructive" onClick={handleLogout}>تسجيل الخروج</Button>
                <AdminPanel />
             </div>
          </div>
        </CardContent>
      </Card>
    </div>
    <AvatarSelectionDialog 
        open={isAvatarDialogOpen}
        onOpenChange={setIsAvatarDialogOpen}
        onSelect={handleAvatarSelect}
      />
    <ChangeEmailDialog 
        open={isEmailDialogOpen}
        onOpenChange={setIsEmailDialogOpen}
    />
    </>
  );
}

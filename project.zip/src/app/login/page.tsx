
import { AuthCard } from "@/components/auth/AuthCard";
import { WeMeetLogo } from "@/components/layout/WeMeetLogo";
import Image from 'next/image';
import Link from 'next/link';

export default function LoginPage() {
  return (
    <main className="relative flex min-h-screen flex-col items-center justify-center p-4 md:p-8" dir="rtl">
       <Image
        src="https://images.unsplash.com/photo-1551434678-e076c223a692?q=80&w=2070&auto=format&fit=crop"
        alt="Background"
        fill
        className="object-cover -z-20"
      />
      <div className="absolute inset-0 bg-blue-900/50 -z-10" />
      <div className="flex w-full max-w-sm flex-col items-center gap-8">
        <AuthCard />
      </div>
    </main>
  );
}

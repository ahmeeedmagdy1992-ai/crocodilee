import Link from "next/link";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import Image from "next/image";
import { WeMeetLogo } from "@/components/layout/WeMeetLogo";

export default function WelcomePage() {
  return (
    <div className="relative min-h-screen w-full flex flex-col items-center justify-center text-white overflow-hidden">
        <Image
            src="https://images.unsplash.com/photo-1551434678-e076c223a692?q=80&w=2070&auto=format&fit=crop"
            alt="App Background"
            fill
            className="object-cover -z-20"
        />
        <div className="absolute inset-0 bg-blue-900/60 backdrop-blur-sm -z-10" />

      <div className="container mx-auto flex flex-col items-center justify-center text-center p-4" dir="rtl">
        <WeMeetLogo className="text-6xl md:text-8xl mb-6" />
        <div className="max-w-2xl">
          <p className="mt-4 text-lg md:text-xl text-blue-100">
            مساحة جديدة للتواصل الاجتماعي ومشاركة الأفكار والاهتمامات.
          </p>
          <p className="mt-2 text-lg md:text-xl text-blue-100">
            كوّن صداقات، انضم لغرف الدردشة، وشارك المحتوى الذي يعبر عنك.
          </p>
          <p className="mt-4 text-xl md:text-2xl text-white font-semibold">
            انطلق الآن واكتشف عالمًا جديدًا من التواصل الاجتماعي.
          </p>
        </div>
        <Button
          asChild
          className="mt-8 bg-primary hover:bg-primary/90 text-primary-foreground font-bold py-3 px-8 text-lg rounded-full shadow-lg transition-transform transform hover:scale-105"
        >
          <Link href="/login">
            استمرار
            <ArrowRight className="mr-2 h-5 w-5" />
          </Link>
        </Button>
      </div>
    </div>
  );
}


import { redirect } from 'next/navigation'

export default function SignupPage() {
  // Redirect to the login page which now contains the signup tab
  redirect('/login?tab=signup');
}


import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import Image from 'next/image';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

export default function TermsPage() {
  return (
    <main className="relative flex min-h-screen flex-col items-center justify-center p-4 md:p-8" dir="rtl">
       <Image
        src="https://images.unsplash.com/photo-1551434678-e076c223a692?q=80&w=2070&auto=format&fit=crop"
        alt="Background"
        fill
        className="object-cover -z-20"
      />
      <div className="absolute inset-0 bg-blue-900/60 -z-10" />
      
      <div className="w-full max-w-4xl text-white">
        <Card className="bg-card/80 backdrop-blur-sm text-card-foreground">
            <CardHeader>
                <CardTitle className="text-3xl font-headline text-center">الشروط والأحكام</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-right">
                <p>مرحبًا بك في WeMeet. باستخدام تطبيقنا، فإنك توافق على الالتزام بالشروط والأحكام التالية. يرجى قراءتها بعناية.</p>
                
                <h3 className="text-xl font-semibold">1. قبول الشروط</h3>
                <p>من خلال الوصول إلى تطبيقنا أو استخدامه، فإنك توافق على الالتزام بهذه الشروط. إذا كنت لا توافق على أي جزء من الشروط، فلا يجوز لك الوصول إلى الخدمة.</p>

                <h3 className="text-xl font-semibold">2. استخدام الحساب</h3>
                <p>أنت مسؤول عن الحفاظ على سرية حسابك وكلمة مرورك. يجب أن يكون عمرك 13 عامًا على الأقل لاستخدام هذه الخدمة.</p>

                <h3 className="text-xl font-semibold">3. المحتوى</h3>
                <p>أنت مسؤول عن المحتوى الذي تنشره. من خلال النشر، فإنك تمنحنا ترخيصًا عالميًا وغير حصري وخاليًا من حقوق الملكية لاستخدام هذا المحتوى وتوزيعه. لا يجوز لك نشر محتوى غير قانوني أو مسيء أو ينتهك حقوق الآخرين.</p>

                <h3 className="text-xl font-semibold">4. إنهاء الخدمة</h3>
                <p>يجوز لنا إنهاء أو تعليق وصولك إلى خدمتنا على الفور، دون إشعار مسبق أو مسؤولية، لأي سبب من الأسباب، بما في ذلك على سبيل المثال لا الحصر إذا انتهكت الشروط.</p>

                <h3 className="text-xl font-semibold">5. تغييرات على الشروط</h3>
                <p>نحتفظ بالحق، وفقًا لتقديرنا الخاص، في تعديل أو استبدال هذه الشروط في أي وقت. سنقدم إشعارًا قبل 30 يومًا على الأقل من دخول أي شروط جديدة حيز التنفيذ.</p>

                 <div className="text-center pt-6">
                    <Button asChild>
                        <Link href="/login">
                            <ArrowRight className="ml-2 h-5 w-5" />
                            العودة إلى تسجيل الدخول
                        </Link>
                    </Button>
                </div>
            </CardContent>
        </Card>
      </div>
    </main>
  );
}

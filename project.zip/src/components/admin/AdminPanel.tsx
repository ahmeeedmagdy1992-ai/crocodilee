"use client";

import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { useCollection, useFirebase, useMemoFirebase } from '@/firebase';
import { collection, doc, addDoc, serverTimestamp, query } from 'firebase/firestore';
import { deleteDocumentNonBlocking, addDocumentNonBlocking } from '@/firebase/non-blocking-updates';
import { useToast } from '@/hooks/use-toast';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';

const ADMIN_CODE = "1911";

function RoomsPanel({ firestore }: { firestore: any }) {
    const { toast } = useToast();
    const [newRoomName, setNewRoomName] = useState('');
    const [newRoomType, setNewRoomType] = useState('General');

    const roomsCollection = useMemoFirebase(() => firestore ? collection(firestore, 'chat_rooms') : null, [firestore]);
    const roomsQuery = useMemoFirebase(() => roomsCollection ? query(roomsCollection) : null, [roomsCollection]);
    const { data: rooms, isLoading: roomsLoading } = useCollection(roomsQuery);
    
    const handleCreateRoom = () => {
        if (!newRoomName.trim() || !roomsCollection) return;

        const newRoom = {
            name: newRoomName,
            type: newRoomType,
            adminUsers: [], // Initially no admin users
            createdAt: serverTimestamp(),
        };

        addDocumentNonBlocking(roomsCollection, newRoom);
        toast({ title: "Room Created", description: `Room "${newRoomName}" has been created.` });
        setNewRoomName('');
    };
    
    const handleDeleteRoom = (roomId: string) => {
        const roomRef = doc(firestore, 'chat_rooms', roomId);
        deleteDocumentNonBlocking(roomRef);
        toast({ title: "Room Deleted", description: "The room has been removed." });
    };

    return (
        <div className="space-y-4">
             <div className="flex gap-2 p-4 border rounded-lg">
                <Input 
                    placeholder="New Room Name" 
                    value={newRoomName} 
                    onChange={(e) => setNewRoomName(e.target.value)}
                />
                 <Select value={newRoomType} onValueChange={setNewRoomType}>
                    <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Room Type" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="General">General</SelectItem>
                        <SelectItem value="Community">Community</SelectItem>
                        <SelectItem value="Talent">Talent (Voice)</SelectItem>
                    </SelectContent>
                </Select>
                <Button onClick={handleCreateRoom} disabled={!newRoomName.trim()}>Create Room</Button>
            </div>
            <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Room Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {roomsLoading ? <TableRow><TableCell colSpan={3}>Loading...</TableCell></TableRow> :
                  rooms?.map(room => (
                        <TableRow key={room.id}>
                          <TableCell>{room.name}</TableCell>
                          <TableCell>{room.type}</TableCell>
                          <TableCell>
                            <Button onClick={() => handleDeleteRoom(room.id)} variant="destructive" size="sm">Delete</Button>
                          </TableCell>
                        </TableRow>
                    )
                  )}
                </TableBody>
              </Table>
        </div>
    );
}

export function AdminPanel() {
  const [open, setOpen] = useState(false);
  const [code, setCode] = useState("");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [error, setError] = useState("");

  const { firestore } = useFirebase();
  const { toast } = useToast();
  
  const postsCollection = useMemoFirebase(() => firestore ? collection(firestore, 'posts') : null, [firestore]);
  const { data: posts, isLoading: postsLoading } = useCollection(postsCollection);
  
  const handleCodeCheck = () => {
    if (code === ADMIN_CODE) {
      setIsAuthenticated(true);
      setError("");
    } else {
      setError("Invalid admin code.");
    }
  };
  
  const resetState = (isOpen: boolean) => {
    setOpen(isOpen);
    if (!isOpen) {
      setCode("");
      setIsAuthenticated(false);
      setError("");
    }
  }

  const handleDeletePost = (postId: string) => {
      if(!firestore) return;
      const postRef = doc(firestore, 'posts', postId);
      deleteDocumentNonBlocking(postRef);
      toast({title: "Post Deleted", description: "The post has been removed."})
  }

  return (
    <Dialog open={open} onOpenChange={resetState}>
      <DialogTrigger asChild>
        <Button variant="outline">Admin Panel</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] md:max-w-2xl lg:max-w-4xl">
        <DialogHeader>
          <DialogTitle className="font-headline">Admin Panel</DialogTitle>
          <DialogDescription>
            {isAuthenticated ? "Manage users, posts, and rooms." : "Enter the code to access admin controls."}
          </DialogDescription>
        </DialogHeader>
        {!isAuthenticated ? (
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="admin-code" className="text-right">
                Code
              </Label>
              <Input
                id="admin-code"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="col-span-3"
                type="password"
              />
            </div>
            {error && <p className="text-destructive text-center text-sm">{error}</p>}
            <Button onClick={handleCodeCheck}>Unlock</Button>
          </div>
        ) : (
          <Tabs defaultValue="posts" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="users">Users</TabsTrigger>
              <TabsTrigger value="posts">Posts</TabsTrigger>
              <TabsTrigger value="rooms">Rooms</TabsTrigger>
            </TabsList>
            <TabsContent value="users">
              <div className="text-center text-muted-foreground p-8">
                  User management requires admin privileges and specific queries. Listing all users is restricted for security.
              </div>
            </TabsContent>
            <TabsContent value="posts">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Post Content</TableHead>
                    <TableHead>Author ID</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {postsLoading ? <TableRow><TableCell colSpan={3}>Loading...</TableCell></TableRow> :
                  posts?.map(post => {
                    return (
                        <TableRow key={post.id}>
                          <TableCell className="truncate max-w-sm">{post.content}</TableCell>
                          <TableCell className="font-mono text-xs">{post.authorId}</TableCell>
                          <TableCell>
                            <Button onClick={() => handleDeletePost(post.id)} variant="destructive" size="sm">Delete</Button>
                          </TableCell>
                        </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </TabsContent>
            <TabsContent value="rooms">
                {firestore ? <RoomsPanel firestore={firestore} /> : <p>Loading...</p>}
            </TabsContent>
          </Tabs>
        )}
      </DialogContent>
    </Dialog>
  );
}

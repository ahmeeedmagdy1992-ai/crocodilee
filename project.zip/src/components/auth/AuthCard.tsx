
"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Eye, EyeOff } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { useAuth, useUser, useFirestore, FirestorePermissionError, errorEmitter } from "@/firebase";
import { setDocumentNonBlocking } from "@/firebase/non-blocking-updates";
import { WeMeetLogo } from "../layout/WeMeetLogo";
import { doc, collection, query, where, getDocs, limit } from "firebase/firestore";
import { AuthError, createUserWithEmailAndPassword, signInWithEmailAndPassword } from "firebase/auth";


const loginSchema = z.object({
  username: z.string().min(1, "اسم المستخدم مطلوب."),
  password: z.string().min(1, "كلمة المرور مطلوبة."),
});

const signupSchema = z.object({
  username: z.string().min(3, "يجب أن يكون اسم المستخدم 3 أحرف على الأقل.").regex(/^[a-zA-Z0-9_]+$/, "اسم المستخدم يمكن أن يحتوي فقط على حروف وأرقام وشرطة سفلية."),
  email: z.string().email("الرجاء إدخال بريد إلكتروني صالح.").optional().or(z.literal('')),
  password: z.string().min(6, "يجب أن تكون كلمة المرور 6 أحرف على الأقل."),
  confirmPassword: z.string(),
  agreeToTerms: z.boolean().refine(val => val === true, {
    message: "يجب الموافقة على الشروط والأحكام.",
  }),
}).refine(data => data.password === data.confirmPassword, {
  message: "كلمتا المرور غير متطابقتين.",
  path: ["confirmPassword"],
});


export function AuthCard() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const auth = useAuth();
  const firestore = useFirestore();
  const { user, isUserLoading } = useUser();
  const [activeTab, setActiveTab] = useState(searchParams.get("tab") || "login");
  const [showPassword, setShowPassword] = useState(false);

  const loginForm = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: { username: "", password: "" },
  });

  const signupForm = useForm<z.infer<typeof signupSchema>>({
    resolver: zodResolver(signupSchema),
    defaultValues: { username: "", email: "", password: "", confirmPassword: "", agreeToTerms: false },
  });

  useEffect(() => {
    if (user && !isUserLoading) {
      router.push("/communities");
    }
  }, [user, isUserLoading, router]);

  const handleAuthError = (error: AuthError) => {
    let title = "حدث خطأ";
    let description = "فشل في المصادقة. الرجاء المحاولة مرة أخرى.";

    if (error.code === 'auth/email-already-in-use') {
      title = "البريد الإلكتروني مستخدم";
      description = "هذا البريد الإلكتروني مسجل بالفعل. الرجاء تسجيل الدخول أو استخدام بريد آخر.";
    } else if (error.code === 'auth/invalid-credential' || error.code === 'auth/wrong-password' || error.code === 'auth/user-not-found') {
      title = "معلومات الدخول غير صحيحة";
      description = "اسم المستخدم أو كلمة المرور غير صحيحة. الرجاء التحقق والمحاولة مرة أخرى.";
    } else if (error.code === 'auth/weak-password') {
        title = "كلمة مرور ضعيفة";
        description = "يجب أن تتكون كلمة المرور من 6 أحرف على الأقل."
    } else if (error.code === 'auth/invalid-email') {
        title = "بريد إلكتروني غير صالح";
        description = "البريد الإلكتروني الذي تم إدخاله لإنشاء الحساب غير صالح."
    }
    
    toast({ variant: "destructive", title, description });
  };
  
  async function handleLogin(values: z.infer<typeof loginSchema>) {
    if(!auth || !firestore) return;

    // 1. Find user by username
    const usersRef = collection(firestore, "users");
    const q = query(usersRef, where("username", "==", values.username.toLowerCase()), limit(1));
    
    try {
        const querySnapshot = await getDocs(q);
        if (querySnapshot.empty) {
            handleAuthError({ code: 'auth/user-not-found', name: 'FirebaseError', message: 'User not found' });
            return;
        }

        const userDoc = querySnapshot.docs[0];
        const userData = userDoc.data();
        const email = userData.email;

        if (!email) {
             handleAuthError({ code: 'auth/user-not-found', name: 'FirebaseError', message: 'لا يوجد بريد إلكتروني مسجل لهذا الحساب. لا يمكن تسجيل الدخول.' });
            return;
        }
        
        // 2. Sign in with the found email
        signInWithEmailAndPassword(auth, email, values.password)
            .then((userCredential) => {
                toast({ title: "تم تسجيل الدخول بنجاح!", description: `مرحباً بعودتك.` });
            })
            .catch(handleAuthError);

    } catch (error) {
        handleAuthError({ code: 'auth/internal-error', name: 'FirebaseError', message: 'An internal error occurred' });
    }
  }

  async function handleSignup(values: z.infer<typeof signupSchema>) {
    if (!auth || !firestore) return;

    // Check if username already exists
    const usersRef = collection(firestore, "users");
    const q = query(usersRef, where("username", "==", values.username.toLowerCase()), limit(1));
    const querySnapshot = await getDocs(q);

    if (!querySnapshot.empty) {
        signupForm.setError("username", {
            type: "manual",
            message: "اسم المستخدم هذا موجود بالفعل. الرجاء اختيار اسم آخر.",
        });
        return;
    }
    
    // Use a placeholder email if none is provided, necessary for Firebase Auth
    const emailToRegister = values.email || `${values.username}@wemeet.local`;


    createUserWithEmailAndPassword(auth, emailToRegister, values.password)
        .then(userCredential => {
            const newUser = userCredential.user;
            const userDocRef = doc(firestore, "users", newUser.uid);
            const newUserProfile = {
                id: newUser.uid,
                username: values.username.toLowerCase(),
                displayName: values.username,
                // Only store email if user provided it
                ...(values.email && { email: values.email }),
                profilePictureUrl: `https://picsum.photos/seed/${newUser.uid}/400/400`,
                status: 'مستخدم جديد!',
                friends: [],
                blockedUsers: []
            };
            
            setDocumentNonBlocking(userDocRef, newUserProfile, { merge: false });

            toast({
                title: "تم إنشاء الحساب بنجاح!",
                description: `أهلاً بك في WeMeet, ${values.username}!`,
            });
        })
        .catch(handleAuthError);
  }

  if (isUserLoading) {
    return <Card className="w-full max-w-sm p-8 flex items-center justify-center bg-card/90 backdrop-blur-sm border-white/20"><p>جار التحميل...</p></Card>;
  }

  if (user) {
    return null; // Don't render anything if user is logged in
  }

  return (
    <Card className="w-full max-w-sm bg-card/90 backdrop-blur-sm border-white/20">
      <CardHeader className="text-center">
        <div className="flex justify-center mb-4">
          <WeMeetLogo className="text-5xl" />
        </div>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="login">تسجيل الدخول</TabsTrigger>
            <TabsTrigger value="signup">إنشاء حساب</TabsTrigger>
          </TabsList>
          
          {/* Login Tab */}
          <TabsContent value="login">
            <CardHeader className="p-2 text-center">
              <CardTitle className="text-2xl font-headline">مرحباً بعودتك</CardTitle>
              <CardDescription>أدخل بياناتك للوصول إلى حسابك.</CardDescription>
            </CardHeader>
            <Form {...loginForm}>
              <form onSubmit={loginForm.handleSubmit(handleLogin)} className="space-y-4">
                <FormField
                  control={loginForm.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>اسم المستخدم</FormLabel>
                      <FormControl>
                        <Input placeholder="اسم المستخدم الخاص بك" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={loginForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>كلمة المرور</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Input type={showPassword ? "text" : "password"} placeholder="••••••••" {...field} />
                          <Button type="button" variant="ghost" size="icon" className="absolute left-1 top-1/2 -translate-y-1/2 h-7 w-7" onClick={() => setShowPassword(!showPassword)}>
                            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </Button>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" className="w-full" disabled={loginForm.formState.isSubmitting}>تسجيل الدخول</Button>
              </form>
            </Form>
          </TabsContent>

          {/* Signup Tab */}
          <TabsContent value="signup">
            <CardHeader className="p-2 text-center">
                <CardTitle className="text-2xl font-headline">إنشاء حساب جديد</CardTitle>
                <CardDescription>انضم إلينا في خطوات بسيطة.</CardDescription>
            </CardHeader>
             <Form {...signupForm}>
                <form onSubmit={signupForm.handleSubmit(handleSignup)} className="space-y-4">
                    <FormField
                        control={signupForm.control}
                        name="username"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>اسم المستخدم</FormLabel>
                                <FormControl>
                                    <Input placeholder="مثال: ahmed123" {...field} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={signupForm.control}
                        name="email"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>البريد الإلكتروني <span className="text-muted-foreground text-xs">(اختياري للاسترداد)</span></FormLabel>
                                <FormControl>
                                    <Input placeholder="name@example.com" {...field} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={signupForm.control}
                        name="password"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>كلمة المرور</FormLabel>
                                <FormControl>
                                    <div className="relative">
                                    <Input type={showPassword ? "text" : "password"} placeholder="••••••••" {...field} />
                                    <Button type="button" variant="ghost" size="icon" className="absolute left-1 top-1/2 -translate-y-1/2 h-7 w-7" onClick={() => setShowPassword(!showPassword)}>
                                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                                    </Button>
                                    </div>
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={signupForm.control}
                        name="confirmPassword"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>تأكيد كلمة المرور</FormLabel>
                                <FormControl>
                                    <Input type={showPassword ? "text" : "password"} placeholder="••••••••" {...field} />
                                </FormControl>
                                <FormMessage />
                            </FormItem>
                        )}
                    />
                    <FormField
                        control={signupForm.control}
                        name="agreeToTerms"
                        render={({ field }) => (
                            <FormItem className="flex flex-row items-center space-x-3 space-y-0 rounded-md p-4">
                                <FormControl>
                                    <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                                </FormControl>
                                <div className="space-y-1 leading-none">
                                    <FormLabel>
                                        أوافق على <Link href="/terms" className="text-primary underline hover:text-primary/80">الشروط والأحكام</Link>
                                    </FormLabel>
                                     <FormMessage />
                                </div>
                            </FormItem>
                        )}
                    />
                    <Button type="submit" className="w-full" disabled={signupForm.formState.isSubmitting}>إنشاء حساب</Button>
                </form>
            </Form>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

    
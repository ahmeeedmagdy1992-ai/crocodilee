import { type Conversation } from "@/lib/data";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";

export function ConversationItem({ conversation, isLast }: { conversation: Conversation, isLast: boolean }) {
  return (
    <div
      className={cn(
        "flex items-center gap-4 p-4 hover:bg-muted/50 cursor-pointer",
        !isLast && "border-b"
      )}
    >
      <Avatar className="h-12 w-12">
        <AvatarImage src={conversation.user.avatar} alt={conversation.user.name} />
        <AvatarFallback>{conversation.user.name.charAt(0)}</AvatarFallback>
      </Avatar>
      <div className="flex-1 grid gap-1 overflow-hidden">
        <div className="flex items-baseline justify-between">
            <p className="font-semibold truncate">{conversation.user.name}</p>
            <p className="text-xs text-muted-foreground flex-shrink-0">{conversation.timestamp}</p>
        </div>
        <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground truncate">{conversation.lastMessage}</p>
            {conversation.unread > 0 && (
                <Badge className="bg-primary hover:bg-primary text-primary-foreground h-5 w-5 flex items-center justify-center p-0">{conversation.unread}</Badge>
            )}
        </div>
      </div>
    </div>
  );
}

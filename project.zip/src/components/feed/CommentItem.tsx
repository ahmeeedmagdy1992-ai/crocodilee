"use client";

import { useFirebase, useMemoFirebase } from "@/firebase";
import { type Comment } from "@/lib/data";
import { arrayRemove, arrayUnion, doc } from "firebase/firestore";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useDoc } from "@/firebase/firestore/use-doc";
import { formatDistanceToNow } from 'date-fns';
import { ar } from 'date-fns/locale';
import { Button } from "../ui/button";
import { Heart } from "lucide-react";
import { cn } from "@/lib/utils";
import { updateDocumentNonBlocking } from "@/firebase/non-blocking-updates";

interface CommentItemProps {
    comment: Comment;
}

export function CommentItem({ comment }: CommentItemProps) {
    const { firestore, user } = useFirebase();

    const authorRef = useMemoFirebase(() => {
        if (!firestore) return null;
        return doc(firestore, 'users', comment.authorId);
    }, [firestore, comment.authorId]);

    const { data: author } = useDoc(authorRef);
    
    const commentRef = useMemoFirebase(() => {
        if (!firestore) return null;
        return doc(firestore, 'posts', comment.postId, 'comments', comment.id);
    }, [firestore, comment.postId, comment.id]);

    const isLiked = user ? comment.likes?.includes(user.uid) : false;

    const handleLike = () => {
        if (!commentRef || !user) return;

        const newLikes = isLiked 
            ? arrayRemove(user.uid) 
            : arrayUnion(user.uid);

        updateDocumentNonBlocking(commentRef, { likes: newLikes });
    };

    if (!author) {
        return (
             <div className="flex items-start gap-4">
                <div className="h-10 w-10 rounded-full bg-muted animate-pulse" />
                <div className="flex-1 space-y-2">
                     <div className="h-4 w-24 rounded bg-muted animate-pulse" />
                     <div className="h-4 w-48 rounded bg-muted animate-pulse" />
                </div>
            </div>
        );
    }
    
    const timeAgo = comment.createdAt ? formatDistanceToNow(comment.createdAt.toDate(), { addSuffix: true, locale: ar }) : 'الآن';

    return (
        <div className="flex items-start gap-4">
            <Avatar>
                <AvatarImage src={author.profilePictureUrl} alt={author.displayName} />
                <AvatarFallback>{author.displayName?.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
                <div className="flex items-center gap-2">
                    <p className="font-semibold">{author.displayName}</p>
                    <p className="text-xs text-muted-foreground">{timeAgo}</p>
                </div>
                <p className="text-muted-foreground">{comment.content}</p>
                <div className="flex items-center gap-2 mt-1">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleLike}>
                         <Heart className={cn("h-4 w-4", isLiked && "fill-red-500 text-red-500")} />
                    </Button>
                    <span className="text-xs text-muted-foreground">
                        {comment.likes?.length || 0}
                    </span>
                </div>
            </div>
        </div>
    )
}

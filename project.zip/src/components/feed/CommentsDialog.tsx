"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useCollection, useFirebase, useMemoFirebase } from "@/firebase";
import { collection, query, orderBy, doc, serverTimestamp, updateDoc, increment } from "firebase/firestore";
import { type Comment as CommentType } from "@/lib/data";
import { CommentItem } from "./CommentItem";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem } from "@/components/ui/form";
import { Textarea } from "../ui/textarea";
import { Button } from "../ui/button";
import { addDocumentNonBlocking } from "@/firebase/non-blocking-updates";

interface CommentsDialogProps {
  postId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const commentSchema = z.object({
  content: z.string().min(1, "لا يمكن أن يكون التعليق فارغًا.").max(500, "لا يمكن أن يتجاوز التعليق 500 حرف."),
});

export function CommentsDialog({ postId, open, onOpenChange }: CommentsDialogProps) {
  const { firestore, user } = useFirebase();

  const commentsCollectionRef = useMemoFirebase(() => {
    if (!firestore || !postId) return null;
    return collection(firestore, "posts", postId, "comments");
  }, [firestore, postId]);
  
  const commentsQuery = useMemoFirebase(() => {
    if (!commentsCollectionRef) return null;
    return query(commentsCollectionRef, orderBy("createdAt", "desc"));
  }, [commentsCollectionRef]);
  
  const { data: comments, isLoading } = useCollection<CommentType>(commentsQuery);

  const form = useForm<z.infer<typeof commentSchema>>({
    resolver: zodResolver(commentSchema),
    defaultValues: { content: "" },
  });

  const onSubmit = (values: z.infer<typeof commentSchema>) => {
    if (!commentsCollectionRef || !user || !firestore) return;
    
    const newComment = {
      authorId: user.uid,
      postId: postId,
      content: values.content,
      createdAt: serverTimestamp(),
    };
    
    addDocumentNonBlocking(commentsCollectionRef, newComment);
    
    // Increment the comment count on the post
    const postRef = doc(firestore, 'posts', postId);
    updateDoc(postRef, { commentCount: increment(1) });

    form.reset();
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" dir="rtl">
        <DialogHeader>
          <DialogTitle>التعليقات</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col h-[60vh]">
            <ScrollArea className="flex-1 pr-4">
                 <div className="space-y-6">
                    {isLoading && <p className="text-center text-muted-foreground">جار تحميل التعليقات...</p>}
                    {comments?.map((comment) => (
                        <CommentItem key={comment.id} comment={comment} />
                    ))}
                    {!isLoading && comments?.length === 0 && (
                        <p className="text-center text-muted-foreground py-8">لا توجد تعليقات بعد. كن أول من يعلق!</p>
                    )}
                 </div>
            </ScrollArea>
             <Separator className="my-4" />
            <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="flex items-start gap-2">
                     <FormField
                        control={form.control}
                        name="content"
                        render={({ field }) => (
                            <FormItem className="flex-1">
                                <FormControl>
                                    <Textarea placeholder="أضف تعليقًا..." {...field} rows={1} className="min-h-0"/>
                                </FormControl>
                            </FormItem>
                        )}
                        />
                    <Button type="submit" disabled={form.formState.isSubmitting}>نشر</Button>
                </form>
            </Form>
        </div>
      </DialogContent>
    </Dialog>
  );
}


"use client";

import Image from "next/image";
import { Heart, MessageSquare, Share2, PlayCircle } from "lucide-react";

import { type Post } from "@/lib/data";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
} from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useFirebase } from "@/firebase";
import { doc, updateDoc, arrayUnion, arrayRemove } from "firebase/firestore";
import { cn } from "@/lib/utils";
import { CommentsDialog } from "./CommentsDialog";
import { useState } from "react";

type PostCardProps = {
  post: Post & { likes: string[], commentCount: number };
};

export function PostCard({ post }: PostCardProps) {
  const { toast } = useToast();
  const { firestore, user } = useFirebase();
  const [isCommentsOpen, setIsCommentsOpen] = useState(false);


  const handleFeatureNotAvailable = (featureName: string) => {
    toast({
      title: "الميزة قيد التطوير",
      description: `ميزة ${featureName} ستكون متاحة قريبًا.`,
    });
  };

  const postRef = firestore ? doc(firestore, "posts", post.id) : null;
  const isLiked = user ? post.likes.includes(user.uid) : false;

  const handleLike = () => {
    if (!postRef || !user) {
      toast({
        variant: "destructive",
        title: "يجب عليك تسجيل الدخول أولاً",
      });
      return;
    }

    if (isLiked) {
      updateDoc(postRef, {
        likes: arrayRemove(user.uid)
      });
    } else {
      updateDoc(postRef, {
        likes: arrayUnion(user.uid)
      });
    }
  };


  return (
    <>
    <Card className="overflow-hidden bg-card/80 backdrop-blur-sm">
      <CardHeader className="flex flex-row items-center gap-4">
        <Avatar>
          <AvatarImage src={post.author.avatar} alt={post.author.name} />
          <AvatarFallback>{post.author.name.charAt(0)}</AvatarFallback>
        </Avatar>
        <div className="grid gap-1">
          <p className="font-semibold">{post.author.name}</p>
          <p className="text-sm text-muted-foreground">{post.timestamp}</p>
        </div>
      </CardHeader>
      <CardContent>
        <p className="mb-4 whitespace-pre-wrap">{post.content}</p>
        {post.image && (
          <div className="relative aspect-video w-full overflow-hidden rounded-lg">
            <Image
              src={post.image.url}
              alt="Post image"
              fill
              className="object-cover"
              data-ai-hint={post.image.hint}
            />
          </div>
        )}
        {post.video && (
            <div className="relative aspect-video w-full overflow-hidden rounded-lg bg-black">
                <video 
                    src={post.video.url}
                    controls 
                    className="w-full h-full object-contain"
                >
                    Your browser does not support the video tag.
                </video>
            </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between border-t px-6 py-3">
        <Button variant="ghost" className="flex items-center gap-2" onClick={handleLike}>
          <Heart className={cn("h-5 w-5", isLiked && "fill-red-500 text-red-500")} />
          <span>{post.likes.length} إعجاب</span>
        </Button>
        <Button variant="ghost" className="flex items-center gap-2" onClick={() => setIsCommentsOpen(true)}>
          <MessageSquare className="h-5 w-5" />
          <span>{post.commentCount} تعليق</span>
        </Button>
        <Button variant="ghost" className="flex items-center gap-2" onClick={() => handleFeatureNotAvailable("المشاركة")}>
          <Share2 className="h-5 w-5" />
          <span>مشاركة</span>
        </Button>
      </CardFooter>
    </Card>
    <CommentsDialog postId={post.id} open={isCommentsOpen} onOpenChange={setIsCommentsOpen} />
    </>
  );
}

    
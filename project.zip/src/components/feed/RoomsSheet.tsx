
"use client";

import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Mic, MessageCircle, User } from "lucide-react";
import React from "react";
import { ScrollArea } from "../ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { useCollection, useFirebase, useMemoFirebase } from "@/firebase";
import { collection, query } from "firebase/firestore";
import { useRouter } from "next/navigation";

const RoomCard = ({
  icon,
  title,
  description,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  children: React.ReactNode;
}) => (
  <div className="rounded-lg border bg-card text-card-foreground p-4 flex flex-col gap-4">
    <div className="flex items-start gap-4">
      <div className="bg-muted p-3 rounded-lg">{icon}</div>
      <div>
        <h3 className="font-semibold font-headline">{title}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
    {children}
  </div>
);

function RoomItem({ room }: { room: { id: string, name: string, type: string }}) {
    const router = useRouter();
    const { toast } = useToast();

    const handleJoinRoom = (roomId: string) => {
        router.push(`/rooms/${roomId}`);
    };
    
    const handleFeatureNotAvailable = (featureName: string) => {
        toast({
            title: "الميزة قيد التطوير",
            description: `${featureName} ستكون متاحة قريبًا.`,
        });
    };

    const getRoomDetails = (type: string) => {
        switch(type) {
            case 'Talent':
                return { icon: <Mic className="h-6 w-6 text-primary" />, description: "مساحة صوتية مباشرة للمبدعين.", type: "صوتي" };
            case 'General':
                return { icon: <MessageCircle className="h-6 w-6 text-primary" />, description: "مكان للجميع للتحدث.", type: "نصي" };
            case 'Community':
                 return { icon: <MessageCircle className="h-6 w-6 text-primary" />, description: "ناقش مواضيع حول المجتمع.", type: "نصي" };
            default:
                 return { icon: <MessageCircle className="h-6 w-6 text-primary" />, description: "انضم إلى المحادثة.", type: "نصي" };
        }
    }

    const { icon, description, type: roomType } = getRoomDetails(room.type);
    const isVoiceRoom = room.type === 'Talent';

    return (
        <RoomCard
            icon={icon}
            title={room.name}
            description={description}
        >
             {isVoiceRoom && (
                <div className="flex -space-x-2 overflow-hidden p-2 justify-center">
                    {[...Array(5)].map((_, i) => (
                        <div key={i} className="inline-block h-8 w-8 rounded-full ring-2 ring-background bg-muted flex items-center justify-center">
                            <User className="h-4 w-4 text-muted-foreground" />
                        </div>
                    ))}
                </div>
             )}
            <Button 
                className="w-full" 
                onClick={() => isVoiceRoom ? handleFeatureNotAvailable("الغرف الصوتية") : handleJoinRoom(room.id)}
                disabled={isVoiceRoom}
            >
                {roomType === "صوتي" ? "الانضمام إلى الغرفة" : "الانضمام إلى الدردشة"}
            </Button>
        </RoomCard>
    );

}


export function RoomsSheet({ trigger }: { trigger: React.ReactNode }) {
  const { firestore } = useFirebase();

  const roomsCollectionRef = useMemoFirebase(() => {
    if (!firestore) return null;
    return collection(firestore, "chat_rooms");
  }, [firestore]);

  const roomsQuery = useMemoFirebase(() => {
      if (!roomsCollectionRef) return null;
      return query(roomsCollectionRef);
  }, [roomsCollectionRef]);

  const { data: rooms, isLoading } = useCollection(roomsQuery);


  return (
    <Sheet>
      <SheetTrigger asChild>{trigger}</SheetTrigger>
      <SheetContent className="w-full sm:max-w-md">
        <SheetHeader>
          <SheetTitle className="font-headline">الغرف</SheetTitle>
          <SheetDescription>
            انضم إلى الغرف العامة للدردشة والمشاركة مع المجتمع.
          </SheetDescription>
        </SheetHeader>
        <ScrollArea className="h-[calc(100vh-8rem)]">
            <div className="grid gap-4 py-4 pr-4">
                {isLoading && <p className="text-center text-muted-foreground">جاري تحميل الغرف...</p>}
                {rooms?.map(room => (
                    <RoomItem key={room.id} room={room as any} />
                ))}
                {!isLoading && rooms?.length === 0 && <p className="text-center text-muted-foreground">لا توجد غرف متاحة حاليًا.</p>}
            </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}

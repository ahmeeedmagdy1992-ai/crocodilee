
"use client";

import { useFirebase, useMemoFirebase, FirestorePermissionError, errorEmitter } from "@/firebase";
import { type FriendRequest, type User as UserType } from "@/lib/data";
import { doc, collection, query, where, documentId, writeBatch } from "firebase/firestore";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useDoc, useCollection } from "@/firebase/firestore/use-doc";
import { Button } from "../ui/button";
import { Card, CardContent } from "../ui/card";
import { useToast } from "@/hooks/use-toast";
import { Check, X } from "lucide-react";
import { updateDocumentNonBlocking, deleteDocumentNonBlocking, setDocumentNonBlocking } from "@/firebase/non-blocking-updates";

function SenderProfile({ request, senderId }: { request: FriendRequest, senderId: string }) {
    const { firestore } = useFirebase();

    const senderRef = useMemoFirebase(() => {
        if (!firestore) return null;
        return query(collection(firestore, "users"), where(documentId(), "==", senderId));
    }, [firestore, senderId]);

    const { data: senderArr } = useCollection<UserType>(senderRef);
    const { toast } = useToast();
    const { user: currentUser } = useFirebase();

    const handleAcceptRequest = async () => {
        if (!firestore || !currentUser || !senderArr || senderArr.length === 0) return;
        const sender = senderArr[0];
        const requestRef = doc(firestore, 'friend_requests', request.id);
        
        const batch = writeBatch(firestore);

        // 1. Update request status
        batch.update(requestRef, { status: 'accepted' });

        // 2. Add each user to the other's friends subcollection
        const senderFriendRef = doc(firestore, 'users', request.senderId, 'friends', request.receiverId);
        batch.set(senderFriendRef, { friendId: request.receiverId });
        
        const receiverFriendRef = doc(firestore, 'users', request.receiverId, 'friends', request.senderId);
        batch.set(receiverFriendRef, { friendId: request.senderId });

        batch.commit()
            .then(() => {
                toast({ title: "تم قبول الطلب!", description: `أصبحت الآن صديقًا مع ${sender.displayName}.` });
                deleteDocumentNonBlocking(requestRef);
            })
            .catch(error => {
                const contextualError = new FirestorePermissionError({
                    path: requestRef.path,
                    operation: 'update',
                    requestResourceData: { status: 'accepted' }
                });
                errorEmitter.emit('permission-error', contextualError);
            });
    };

    const handleDeclineRequest = () => {
         if (!firestore) return;
        const requestRef = doc(firestore, 'friend_requests', request.id);
        deleteDocumentNonBlocking(requestRef);
        toast({ title: "تم رفض الطلب" });
    }

    if (!senderArr || senderArr.length === 0) {
        return <p>جار التحميل...</p>
    }

    const sender = senderArr[0];

    return (
        <Card className="bg-card/80 backdrop-blur-sm">
            <CardContent className="p-4 flex flex-col items-center gap-4 text-center">
                <Avatar className="h-20 w-20">
                    <AvatarImage src={sender.profilePictureUrl} alt={sender.displayName} />
                    <AvatarFallback>{sender.displayName?.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 grid gap-1">
                    <p className="font-semibold text-lg">{sender.displayName}</p>
                    <p className="text-sm text-muted-foreground truncate">{sender.status}</p>
                </div>
                <div className="flex w-full gap-2 mt-2">
                    <Button size="sm" className="flex-1" onClick={handleAcceptRequest}>
                        <Check className="ml-2 h-4 w-4" />
                        قبول
                    </Button>
                    <Button size="sm" className="flex-1" variant="outline" onClick={handleDeclineRequest}>
                        <X className="ml-2 h-4 w-4" />
                        رفض
                    </Button>
                </div>
            </CardContent>
        </Card>
    )
}


export function FriendRequestCard({ request }: { request: FriendRequest }) {
    return <SenderProfile request={request} senderId={request.senderId} />
}

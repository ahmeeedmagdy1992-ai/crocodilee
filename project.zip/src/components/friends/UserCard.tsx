
"use client";

import { User, MoreVertical, UserPlus, MessageSquare, Clock } from "lucide-react";
import { type User as UserType } from "@/lib/data";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useFirebase, errorEmitter, FirestorePermissionError } from "@/firebase";
import { doc, collection, serverTimestamp } from "firebase/firestore";
import { setDocumentNonBlocking, deleteDocumentNonBlocking, addDocumentNonBlocking } from "@/firebase/non-blocking-updates";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type UserCardProps = {
  user: UserType;
  friendshipStatus: 'friend' | 'pending_sent' | 'not_friend';
};

export function UserCard({ user, friendshipStatus }: UserCardProps) {
    const { firestore, user: currentUser } = useFirebase();
    const { toast } = useToast();

    const handleAddFriend = () => {
        if (!firestore || !currentUser) return;

        const requestsRef = collection(firestore, 'friend_requests');
        addDocumentNonBlocking(requestsRef, {
            senderId: currentUser.uid,
            receiverId: user.id,
            status: 'pending',
            createdAt: serverTimestamp(),
        }).catch(error => {
            const contextualError = new FirestorePermissionError({
                path: 'friend_requests',
                operation: 'create',
                requestResourceData: { senderId: currentUser.uid, receiverId: user.id, status: 'pending' }
            });
            errorEmitter.emit('permission-error', contextualError);
        });
        
        toast({ title: "تم إرسال الطلب!", description: `تم إرسال طلب الصداقة إلى ${user.name}.` });
    };
    
    const handleRemoveFriend = () => {
        if (!firestore || !currentUser) return;
        const currentUserFriendRef = doc(firestore, 'users', currentUser.uid, 'friends', user.id);
        deleteDocumentNonBlocking(currentUserFriendRef);

        const otherUserFriendRef = doc(firestore, 'users', user.id, 'friends', currentUser.uid);
        deleteDocumentNonBlocking(otherUserFriendRef);

        toast({ title: "تمت إزالة الصديق", description: `تمت إزالة ${user.name} من قائمة أصدقائك.` });
    };

    const renderAction = () => {
        switch(friendshipStatus) {
            case 'friend':
                return <Button size="sm" variant="secondary"><MessageSquare className="ml-2 h-4 w-4"/> رسالة</Button>;
            case 'pending_sent':
                return <Button size="sm" variant="secondary" disabled><Clock className="ml-2 h-4 w-4" /> معلق</Button>;
            case 'not_friend':
                return <Button size="sm" onClick={handleAddFriend}><UserPlus className="ml-2 h-4 w-4"/> إضافة صديق</Button>;
            default:
                return null;
        }
    }


  return (
    <Card className="bg-card/80 backdrop-blur-sm">
      <CardContent className="p-4 flex items-center gap-4">
        <Avatar className="h-16 w-16">
          <AvatarImage src={user.avatar} alt={user.name} />
          <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
        </Avatar>
        <div className="flex-1 grid gap-1">
          <p className="font-semibold text-lg">{user.name}</p>
          {user.status && <p className="text-sm text-muted-foreground truncate">{user.status}</p>}
           <div className="flex items-center gap-2 mt-1">
            {renderAction()}
             <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>عرض الملف الشخصي</DropdownMenuItem>
                {friendshipStatus === 'friend' && <DropdownMenuItem onClick={handleRemoveFriend} className="text-destructive focus:text-destructive">إزالة الصديق</DropdownMenuItem>}
                <DropdownMenuItem className="text-destructive focus:text-destructive">حظر المستخدم</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
           </div>
        </div>
      </CardContent>
    </Card>
  );
}

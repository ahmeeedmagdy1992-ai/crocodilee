"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  LayoutGrid,
  MessageSquare,
  Users,
  User,
  PanelLeft,
  Search,
  PlusCircle,
  Settings,
} from "lucide-react";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { WeMeetLogo } from "./WeMeetLogo";
import { useAuth, useUser } from "@/firebase";
import { useEffect } from "react";
import { signOut } from "firebase/auth";

const navItems = [
  { href: "/communities", icon: LayoutGrid, label: "المجتمعات" },
  { href: "/chats", icon: MessageSquare, label: "الدردشات" },
  { href: "/settings", icon: Settings, label: "الإعدادات" },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { user, isUserLoading } = useUser();
  const auth = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!isUserLoading && !user) {
      router.push("/login");
    }
  }, [user, isUserLoading, router]);

  const handleLogout = async () => {
    await signOut(auth);
    router.push("/login");
  };
  
  if (isUserLoading || !user) {
    return (
        <div className="flex min-h-screen w-full flex-col items-center justify-center bg-background/50">
            <WeMeetLogo className="text-5xl" />
            <p className="mt-4">جار التحميل...</p>
        </div>
    );
  }

  return (
    <TooltipProvider>
      <div className="flex min-h-screen w-full flex-col" dir="rtl">
        {/* Desktop Sidebar */}
        <aside className="fixed inset-y-0 right-0 z-10 hidden w-60 flex-col border-l bg-card/80 backdrop-blur-sm sm:flex">
          <nav className="flex flex-col items-center gap-4 px-2 sm:py-5">
            <Link
              href="/communities"
              className="group flex h-9 w-9 shrink-0 items-center justify-center gap-2 rounded-full bg-primary text-lg font-semibold text-primary-foreground md:h-8 md:w-8 md:text-base"
            >
              <WeMeetLogo className="text-xl" />
              <span className="sr-only">WeMeet</span>
            </Link>
            {navItems.map((item) => (
              <Tooltip key={item.href}>
                <TooltipTrigger asChild>
                  <Link
                    href={item.href}
                    className={cn(
                      "flex h-9 w-full justify-start items-center gap-4 rounded-lg px-3 text-muted-foreground transition-colors hover:text-foreground md:h-8",
                      pathname.startsWith(item.href) &&
                        "bg-primary/20 text-primary font-semibold"
                    )}
                  >
                    <item.icon className="h-5 w-5" />
                    <span className="text-sm font-medium">{item.label}</span>
                  </Link>
                </TooltipTrigger>
                <TooltipContent side="left">{item.label}</TooltipContent>
              </Tooltip>
            ))}
          </nav>
        </aside>

        <div className="flex flex-col sm:gap-4 sm:py-4 sm:pr-64">
          <header className="sticky top-0 z-30 flex h-14 items-center gap-4 border-b bg-card/80 backdrop-blur-sm px-4 sm:static sm:h-auto sm:border-0 sm:bg-transparent sm:px-6">
            <Link href="/communities" className="sm:hidden">
                <WeMeetLogo className="text-2xl"/>
                <span className="sr-only">WeMeet</span>
            </Link>
            
            <div className="relative ml-auto flex-1 md:grow-0">
              <Search className="absolute right-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="بحث..."
                className="w-full rounded-lg bg-background/50 pr-8 md:w-[200px] lg:w-[320px]"
              />
            </div>
            <Button variant="ghost" size="icon" className="md:hidden">
              <PlusCircle className="h-6 w-6" />
              <span className="sr-only">منشور جديد</span>
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  size="icon"
                  className="overflow-hidden rounded-full"
                >
                  <Avatar>
                    <AvatarImage
                      src={user.photoURL || undefined}
                      alt={user.displayName || ""}
                    />
                    <AvatarFallback>{user.displayName?.charAt(0) || user.email?.charAt(0)}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>حسابي</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => router.push('/settings')}>الإعدادات</DropdownMenuItem>
                <DropdownMenuItem>الدعم</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>تسجيل الخروج</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </header>
          <main className="grid flex-1 items-start gap-4 p-4 sm:px-6 sm:py-0 md:gap-8">
            {children}
          </main>
        </div>
        
        {/* Mobile Bottom Bar */}
        <footer className="fixed inset-x-0 bottom-0 z-10 border-t bg-card/80 backdrop-blur-sm sm:hidden">
          <nav className="flex items-center justify-around h-16">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex flex-col items-center gap-1 p-2 text-muted-foreground transition-colors hover:text-primary",
                  pathname.startsWith(item.href) && "text-primary"
                )}
              >
                <item.icon className="h-6 w-6" />
                <span className="text-xs font-medium">{item.label}</span>
              </Link>
            ))}
          </nav>
        </footer>
      </div>
    </TooltipProvider>
  );
}

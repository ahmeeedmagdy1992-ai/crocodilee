import { cn } from "@/lib/utils";
import { MessageSquareHeart } from "lucide-react";

export function WeMeetLogo({ className }: { className?: string }) {
    return (
        <div className={cn("flex items-center gap-2", className)}>
            <MessageSquareHeart className="size-1em text-primary" />
            <h1 className="font-extrabold tracking-tight font-headline text-1em">
                WeMeet
            </h1>
        </div>
    );
}

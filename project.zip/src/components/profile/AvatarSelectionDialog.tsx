
"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { PlaceHolderImages } from "@/lib/placeholder-images";
import Image from "next/image";
import { cn } from "@/lib/utils";
import { useCallback, useState } from "react";
import { Button } from "../ui/button";
import { useDropzone } from "react-dropzone";
import { UploadCloud } from "lucide-react";

interface AvatarSelectionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelect: (imageUrl: string) => void;
}

export function AvatarSelectionDialog({ open, onOpenChange, onSelect }: AvatarSelectionDialogProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const userAvatars = PlaceHolderImages.filter(p => p.id.startsWith("user-"));

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e: ProgressEvent<FileReader>) => {
        if (typeof e.target?.result === 'string') {
          setSelectedImage(e.target.result);
        }
      };
      reader.readAsDataURL(file);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/jpeg': [],
      'image/png': [],
      'image/gif': [],
      'image/webp': [],
    },
    multiple: false,
  });

  const handleSelect = () => {
    if(selectedImage) {
        onSelect(selectedImage);
    }
  }

  const handleOpenChange = (isOpen: boolean) => {
    if (!isOpen) {
      setSelectedImage(null);
    }
    onOpenChange(isOpen);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-2xl" dir="rtl">
        <DialogHeader>
          <DialogTitle>اختر صورة رمزية</DialogTitle>
          <DialogDescription>
            اختر صورة لملفك الشخصي من القائمة أدناه أو قم برفع صورة من جهازك.
          </DialogDescription>
        </DialogHeader>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div {...getRootProps()} className={cn("flex flex-col items-center justify-center w-full h-48 border-2 border-dashed rounded-lg cursor-pointer bg-muted hover:bg-muted/80 transition-colors", isDragActive && "border-primary")}>
            <input {...getInputProps()} />
            <div className="flex flex-col items-center justify-center pt-5 pb-6">
              <UploadCloud className="w-8 h-8 mb-4 text-muted-foreground" />
              <p className="mb-2 text-sm text-muted-foreground"><span className="font-semibold">انقر للرفع</span> أو اسحب وأفلت</p>
              <p className="text-xs text-muted-foreground">PNG, JPG, GIF (بحد أقصى 800x800px)</p>
            </div>
          </div>
          {selectedImage && (
             <div className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed rounded-lg bg-muted p-2">
                <p className="text-sm font-medium mb-2">معاينة</p>
                <div className="relative w-32 h-32 rounded-full overflow-hidden">
                    <Image src={selectedImage} alt="Preview" fill className="object-cover" />
                </div>
            </div>
          )}
        </div>
        <ScrollArea className="h-64 w-full rounded-md border p-4">
          <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {userAvatars.map((image) => (
              <button
                key={image.id}
                onClick={() => setSelectedImage(image.imageUrl)}
                className={cn(
                  "relative aspect-square w-full overflow-hidden rounded-full transition-all",
                  "ring-2 ring-transparent hover:ring-primary focus:ring-primary focus:outline-none",
                  selectedImage === image.imageUrl && "ring-primary ring-4"
                )}
              >
                <Image
                  src={image.imageUrl}
                  alt={image.description}
                  fill
                  className="object-cover"
                />
              </button>
            ))}
          </div>
        </ScrollArea>
        <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => handleOpenChange(false)}>إلغاء</Button>
            <Button onClick={handleSelect} disabled={!selectedImage}>
                تأكيد الاختيار
            </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

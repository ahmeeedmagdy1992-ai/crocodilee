
"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useFirebase } from "@/firebase";
import { EmailAuthProvider, reauthenticateWithCredential, verifyBeforeUpdateEmail } from "firebase/auth";

interface ChangeEmailDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const emailSchema = z.object({
  newEmail: z.string().email("الرجاء إدخال بريد إلكتروني صالح."),
  password: z.string().min(1, "كلمة المرور مطلوبة."),
});

export function ChangeEmailDialog({ open, onOpenChange }: ChangeEmailDialogProps) {
  const { user, auth, firestore } = useFirebase();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<z.infer<typeof emailSchema>>({
    resolver: zodResolver(emailSchema),
    defaultValues: { newEmail: "", password: "" },
  });

  const onSubmit = async (values: z.infer<typeof emailSchema>) => {
    if (!user || !auth) {
      toast({
        variant: "destructive",
        title: "خطأ",
        description: "لا يمكن تحديث البريد الإلكتروني. المستخدم غير مسجل الدخول.",
      });
      return;
    }
    
    // Use the official email from the auth user object for re-authentication.
    const currentEmail = user.email;

    if (!currentEmail) {
        toast({
            variant: "destructive",
            title: "خطأ في المصادقة",
            description: "لا يوجد بريد إلكتروني مرتبط بحسابك للتحقق منه. لا يمكن المتابعة.",
        });
        return;
    }
    
    setIsSubmitting(true);
    
    try {
      // 1. Re-authenticate user with their CURRENT email from Auth and the provided password.
      const credential = EmailAuthProvider.credential(currentEmail, values.password);
      await reauthenticateWithCredential(user, credential);
      
      // 2. If re-authentication is successful, send verification to the NEW email.
      await verifyBeforeUpdateEmail(user, values.newEmail);
      
      toast({
        title: "تحقق من بريدك الإلكتروني",
        description: `تم إرسال رابط تحقق إلى ${values.newEmail}. الرجاء النقر على الرابط لإكمال عملية التغيير. قد يستغرق وصول البريد بضع دقائق.`,
        duration: 10000,
      });
      form.reset();
      onOpenChange(false);

    } catch (error: any) {
      let title = "حدث خطأ";
      let description = "فشل تحديث البريد الإلكتروني. يرجى المحاولة مرة أخرى.";

      if (error.code === 'auth/wrong-password' || error.code === 'auth/invalid-credential') {
        title = "كلمة مرور غير صحيحة";
        description = "كلمة المرور الحالية التي أدخلتها غير صحيحة. يرجى التحقق والمحاولة مرة أخرى.";
        form.setError("password", { type: "manual", message: "كلمة المرور غير صحيحة." });
      } else if (error.code === 'auth/email-already-in-use') {
        title = "البريد الإلكتروني مستخدم";
        description = "عنوان البريد الإلكتروني الجديد الذي أدخلته مستخدم بالفعل من قبل حساب آخر.";
        form.setError("newEmail", { type: "manual", message: "هذا البريد الإلكتروني مستخدم بالفعل." });
      } else if (error.code === 'auth/requires-recent-login') {
        title = "جلسة الدخول منتهية";
        description = "لأسباب أمنية، يرجى تسجيل الخروج ثم تسجيل الدخول مرة أخرى قبل تغيير بريدك الإلكتروني.";
      }
       else if (error.code === 'auth/invalid-email') {
        title = "بريد إلكتروني غير صالح";
        description = "البريد الإلكتروني الجديد الذي تم إدخاله غير صالح.";
        form.setError("newEmail", { type: "manual", message: "صيغة البريد الإلكتروني غير صالحة." });
      } else {
        console.error("Change Email Error:", error);
      }

      toast({
        variant: "destructive",
        title: title,
        description: description,
      });
    } finally {
        setIsSubmitting(false);
    }
  };

  const handleOpenChange = (isOpen: boolean) => {
    if (!isOpen) {
      form.reset();
    }
    onOpenChange(isOpen);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md" dir="rtl">
        <DialogHeader>
          <DialogTitle>تغيير البريد الإلكتروني</DialogTitle>
          <DialogDescription>
            أدخل بريدك الإلكتروني الجديد وكلمة المرور الحالية لتأكيد التغيير.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="newEmail"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>البريد الإلكتروني الجديد</FormLabel>
                  <FormControl>
                    <Input placeholder="name@example.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>كلمة المرور الحالية</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="••••••••" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                إلغاء
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "جاري التحديث..." : "تحديث البريد الإلكتروني"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

export const firebaseConfig = {
  "projectId": "studio-7862302800-b7415",
  "appId": "1:645360579844:web:db80aa22df67a70316cc51",
  "apiKey": "AIzaSyAF8PKMO6zAXXSRnWGvCCNIoCBr_y4On08",
  "authDomain": "studio-7862302800-b7415.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "645360579844"
};

import { PlaceHolderImages } from './placeholder-images';

const findImage = (id: string) => PlaceHolderImages.find(img => img.id === id)?.imageUrl || '';

export type User = {
  id: string;
  name: string;
  avatar: string;
  status?: string;
  // Firestore user properties
  username?: string;
  displayName?: string;
  profilePictureUrl?: string;
  friends?: string[];
  blockedUsers?: string[];
};

export type Post = {
  id: string;
  author: User;
  content: string;
  image?: { url: string; hint: string };
  video?: { url: string; hint: string };
  likes: string[];
  comments: number;
  commentCount: number;
  timestamp: string;
  imageUrl?: string;
  videoUrl?: string;
};

export type Conversation = {
  id: string;
  user: User;
  lastMessage: string;
  timestamp: string;
  unread: number;
};

export type Comment = {
    id: string;
    authorId: string;
    postId: string;
    content: string;
    createdAt: any;
    likes: string[];
};

export type FriendRequest = {
    id: string;
    senderId: string;
    receiverId: string;
    status: 'pending' | 'accepted' | 'declined';
    createdAt: any;
};
